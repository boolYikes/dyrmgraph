class User:
  def __init__(self, first, last):
    self.first = first
    self.last = last

  def __getattr__(self, name):
    if name == 'full_name':
      # Optionally cache to avoid recomputing next time:
      value = f'{self.first} {self.last}'
      setattr(self, name, value)  # cache
      return value
    raise AttributeError(f'{type(self).__name__!s} has no attribute {name!r}')


u = User('Ada', 'Lovelace')
print(u.full_name)  # "Ada Lovelace" (computed, then cached)
print(repr(User))
print(repr('abc'))
print('abc')
print(u.full_name)


class Proxy:
  def __init__(self, target):
    self._target = target  # found on Proxy itself; no delegation

  def __getattr__(self, name):
    # Called only if 'name' wasn't found on Proxy
    print(f"Delegating '{name}' to {type(self._target).__name__}")
    return getattr(self._target, name)

  def __len__(self):
    return len(self._target)


t = ['a', 'b', 'c']
p = Proxy(t)

print(p.__len__())  # Delegates to list.__len__ -> 3
print(p.index('b'))  # Delegates to list.index -> 1

print(p.__str__())
